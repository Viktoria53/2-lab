public class Designer extends Worker {
    int numberDesign;

    Designer(String name, int age, String position, double experience, int numberDesign) {
        super(name, age, position, experience);
        this.numberDesign = numberDesign;
    }

    @Override
    void getInfo() {
        System.out.printf("Имя: %s\n" +
                "Возраст: %s\n" +
                "Должность: %s\n" +
                "Опыт: %s\n" +
                "Создано дизайнов: %s\n\n", name, age, position, experience, numberDesign);
    }
}

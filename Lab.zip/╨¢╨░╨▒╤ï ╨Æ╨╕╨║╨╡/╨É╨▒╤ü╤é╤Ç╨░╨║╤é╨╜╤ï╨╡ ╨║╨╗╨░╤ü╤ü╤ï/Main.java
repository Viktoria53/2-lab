public class Main {
    public static void main(String args[]) {
        Tester tester = new Tester("Петр", 24, "Middle-тестировщик", 2.5, 100);
        tester.getInfo();

        Designer designer = new Designer("Ксения", 20, "Старший дизайнер", 6, 333);
        designer.getInfo();

        Programmer programmer = new Programmer("Виктория", 18, "Junior-программист", 1, new String[]{"Java", "C++"});
        programmer.getInfo();
    }
}

public class Tester extends Worker {
    int numberBugs;

    Tester(String name, int age, String position, double experience, int numberBugs) {
        super(name, age, position, experience);
        this.numberBugs = numberBugs;
    }

    @Override
    void getInfo() {
        System.out.printf("Имя: %s\n" +
                "Возраст: %s\n" +
                "Должность: %s\n" +
                "Опыт: %s\n" +
                "Исправленных багов: %s\n\n", name, age, position, experience, numberBugs);
    }
}
